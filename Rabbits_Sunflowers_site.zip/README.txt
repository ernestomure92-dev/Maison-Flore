
# Rabbits & Sunflowers (GitHub Pages)

Pasos rápidos para publicar:

1) Crea un repositorio público en GitHub, por ejemplo `rabbits-sunflowers`.
2) Sube todo el contenido de esta carpeta (incluye `index.html` y `assets/logo.png`).
3) Ve a **Settings → Pages** y selecciona:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/** (root)
4) Guarda. Tu sitio quedará público en: `https://TU-USUARIO.github.io/rabbits-sunflowers`

## Cambiar número de WhatsApp
Edita en `index.html` la constante `WA_NUMBER` (formato MX: 52155XXXXXXXX, sin +).

## Editar catálogo
Modifica el arreglo `CATALOGO` dentro del `<script>` agregando/quitarndo objetos.

## Colores
Ajusta variables CSS en `:root{ ... }`.
